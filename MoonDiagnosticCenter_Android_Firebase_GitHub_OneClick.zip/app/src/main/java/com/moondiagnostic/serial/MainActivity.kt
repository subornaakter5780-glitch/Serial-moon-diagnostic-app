package com.moondiagnostic.serial

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestoreException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var role = "user"
    private var currentPage = "total"
    private var serials = mutableListOf<SerialItem>()
    private var doctors = mutableListOf<String>()
    private var careOfs = mutableListOf<String>()

    private lateinit var content: LinearLayout
    private lateinit var title: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        if (auth.currentUser == null) showLogin() else loadUser(auth.currentUser!!.uid)
    }

    private fun showLogin() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,60,32,32) }
        val h = TextView(this).apply { text = "🌙  মুন ডায়াগনস্টিক সেন্টার\nLogin"; textSize=24f; setTextColor(0xFFB40000.toInt()) }
        val email = EditText(this).apply { hint="ইমেইল"; inputType=33 }
        val pass = EditText(this).apply { hint="পাসওয়ার্ড"; inputType=129 }
        val b = Button(this).apply { text="লগইন" }
        root.addView(h); root.addView(email); root.addView(pass); root.addView(b)
        setContentView(root)
        b.setOnClickListener {
            auth.signInWithEmailAndPassword(email.text.toString().trim(), pass.text.toString())
                .addOnSuccessListener { loadUser(auth.currentUser!!.uid) }
                .addOnFailureListener { toast(it.message ?: "Login failed") }
        }
    }

    private fun loadUser(uid: String) {
        db.collection("users").document(uid).get().addOnSuccessListener { s ->
            if (!s.exists() || s.getBoolean("active") == false) { toast("Account inactive/not configured"); auth.signOut(); showLogin(); return@addOnSuccessListener }
            role = s.getString("role") ?: "user"
            showApp()
        }.addOnFailureListener { toast(it.message ?: "Could not load user") }
    }

    private fun showApp() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { setPadding(20,18,20,12); setBackgroundColor(0xFFB40000.toInt()) }
        title = TextView(this).apply { text="🌙 মুন ডায়াগনস্টিক সেন্টার"; textSize=19f; setTextColor(0xFFFFFFFF.toInt()) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val logout = Button(this).apply { text="Logout" }
        header.addView(logout)
        logout.setOnClickListener { auth.signOut(); showLogin() }
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,14,14,90) }
        val scroll = ScrollView(this); scroll.addView(content)
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(0xFFFFFFFF.toInt()) }
        val items = listOf("📋\nটোটাল সিরিয়াল","➕\nঅ্যাড সিরিয়াল","👨‍⚕️\nঅ্যাড ডাক্তার","👤\nঅ্যাড কেয়ার অফ")
        items.forEachIndexed { i, text ->
            val b=Button(this).apply{text=text; textSize=11f}
            nav.addView(b, LinearLayout.LayoutParams(0,90,1f))
            b.setOnClickListener { currentPage=listOf("total","add","doctor","care")[i]; render() }
        }
        root.addView(header); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); root.addView(nav)
        setContentView(root)
        loadLists(); render()
    }

    private fun render() {
        content.removeAllViews()
        when(currentPage) {
            "total" -> renderTotal()
            "add" -> renderAdd()
            "doctor" -> renderNames(true)
            "care" -> renderNames(false)
        }
    }

    private fun renderTotal() {
        val h=TextView(this).apply{text="📋 Total Serial";textSize=22f}
        content.addView(h)
        val search=EditText(this).apply{hint="🔎 Patient / Doctor / Serial Search"}
        content.addView(search)
        val counts=TextView(this).apply{text="মোট: ${serials.size}   ⏳ ${serials.count{it.status=="অপেক্ষমাণ"}}   ✅ ${serials.count{it.status=="সম্পন্ন"}}   ❌ ${serials.count{it.status=="বাতিল"}}"}
        content.addView(counts)
        serials.sortedBy{it.no}.forEach { x ->
            val c=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(8,12,8,12)}
            val n=TextView(this).apply{text="#${x.no}";textSize=20f;setTextColor(0xFFB40000.toInt())}
            val info=TextView(this).apply{text="${x.patient}\nCare Of: ${x.care}\nDr. ${x.doctor}\n${x.status}";textSize=14f}
            c.addView(n,LinearLayout.LayoutParams(70,-2)); c.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            val share=Button(this).apply{text="↗"}
            share.setOnClickListener{shareSerial(x)}
            c.addView(share)
            if(x.status=="অপেক্ষমাণ" && (role=="admin"||role=="operator")){
                val done=Button(this).apply{text="✓"}
                val cancel=Button(this).apply{text="×"}
                done.setOnClickListener{changeStatus(x,"সম্পন্ন")}
                cancel.setOnClickListener{changeStatus(x,"বাতিল")}
                c.addView(done);c.addView(cancel)
            }
            content.addView(c)
        }
        search.setOnEditorActionListener { _,_,_ -> render(); true }
    }

    private fun renderAdd() {
        content.addView(TextView(this).apply{text="➕ Add Serial";textSize=22f})
        val patient=EditText(this).apply{hint="Patient Name"}
        val care=AutoCompleteTextView(this).apply{hint="Care Of Name";setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,careOfs))}
        val doctor=AutoCompleteTextView(this).apply{hint="Doctor Name";setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,doctors))}
        val add=Button(this).apply{text="সিরিয়াল তৈরি করুন"}
        content.addView(patient);content.addView(care);content.addView(doctor);content.addView(add)
        add.setOnClickListener{createSerial(patient.text.toString().trim(),care.text.toString().trim(),doctor.text.toString().trim())}
    }

    private fun renderNames(doctorMode:Boolean) {
        val name="অ্যাড ডাক্তার".takeIf{doctorMode} ?: "অ্যাড কেয়ার অফ"
        content.addView(TextView(this).apply{text=if(doctorMode)"👨‍⚕️ $name" else "👤 $name";textSize=22f})
        if(role=="admin"){
            val e=EditText(this).apply{hint=if(doctorMode)"ডাক্তারের নাম" else "কেয়ার অফ নাম"}
            val b=Button(this).apply{text="যোগ করুন"}
            content.addView(e);content.addView(b)
            b.setOnClickListener{
                val v=e.text.toString().trim(); if(v.isNotEmpty()) db.collection(if(doctorMode)"doctors" else "careOfs").add(mapOf("name" to v)).addOnSuccessListener{loadLists()}
            }
        }
        (if(doctorMode)doctors else careOfs).forEach{content.addView(TextView(this).apply{text="• $it";textSize=16f;setPadding(8,12,8,12)})}
    }

    private fun loadLists() {
        db.collection("doctors").orderBy("name",Query.Direction.ASCENDING).addSnapshotListener { s,_ ->
            doctors=s?.documents?.mapNotNull{it.getString("name")}?.toMutableList() ?: mutableListOf(); render()
        }
        db.collection("careOfs").orderBy("name",Query.Direction.ASCENDING).addSnapshotListener { s,_ ->
            careOfs=s?.documents?.mapNotNull{it.getString("name")}?.toMutableList() ?: mutableListOf(); render()
        }
        val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        db.collection("serials").whereEqualTo("dateKey",day).orderBy("serialNo",Query.Direction.ASCENDING).addSnapshotListener { s,_ ->
            serials=s?.documents?.map{d->SerialItem(d.id,(d.getLong("serialNo")?:0).toInt(),d.getString("patientName")?:"",d.getString("careOfName")?:"",d.getString("doctorName")?:"",d.getString("status")?:"অপেক্ষমাণ") }?.toMutableList() ?: mutableListOf(); render()
        }
    }

    private fun createSerial(patient:String,care:String,doctor:String) {
        if(patient.isEmpty()||doctor.isEmpty()){toast("Patient ও Doctor দিন");return}
        val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        val counter=db.collection("counters").document(day)
        db.runTransaction { tx ->
            val snap=tx.get(counter); val next=(snap.getLong("lastSerial")?:0)+1
            tx.set(counter,mapOf("lastSerial" to next,"updatedAt" to FieldValue.serverTimestamp()),com.google.firebase.firestore.SetOptions.merge())
            val ref=db.collection("serials").document()
            tx.set(ref,mapOf("dateKey" to day,"serialNo" to next,"patientName" to patient,"careOfName" to care,"doctorName" to doctor,"status" to "অপেক্ষমাণ","createdBy" to auth.currentUser!!.uid,"createdAt" to FieldValue.serverTimestamp()))
            next
        }.addOnSuccessListener{toast("সিরিয়াল #$it তৈরি হয়েছে");currentPage="total";render()}
         .addOnFailureListener{toast("Serial failed: ${it.message}")}
    }

    private fun changeStatus(x:SerialItem,status:String){
        db.collection("serials").document(x.id).update("status",status)
    }
    private fun shareSerial(x:SerialItem){
        val text="মুন ডায়াগনস্টিক সেন্টার\\nসিরিয়াল: #${x.no}\\nPatient: ${x.patient}\\nCare Of: ${x.care}\\nDoctor: ${x.doctor}\\nStatus: ${x.status}"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"সিরিয়াল Share"))
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    data class SerialItem(val id:String,val no:Int,val patient:String,val care:String,val doctor:String,val status:String)
}

# Moon Diagnostic Center — Android + Firebase + One-Click GitHub Build

Features:
- Total Serial
- Add Serial: Patient / Care Of / Doctor
- Add Doctor
- Add Care Of
- Search-ready serial list
- Waiting / Completed / Cancelled
- Share Serial
- Admin / Operator / User role
- Firestore real-time listeners
- Atomic daily counter transaction to avoid duplicate serial numbers across phones
- Firestore rules and indexes
- GitHub Actions APK build

## Mobile build
1. Create a GitHub repository.
2. Upload all files from this project, including `.github/workflows/build-apk.yml`.
3. GitHub → Actions → Build Moon Diagnostic APK → Run workflow.
4. Download `Moon-Diagnostic-APK` from Artifacts.

## Firebase setup (required for real cloud use)
1. Create a Firebase project.
2. Add Android app package: `com.moondiagnostic.serial`.
3. Download the real `google-services.json` and replace `app/google-services.json`.
4. Enable Authentication → Email/Password.
5. Create Firestore Database.
6. Deploy `firestore.rules` and `firestore.indexes.json`.
7. Create `users/{uid}` documents:
   role: admin | operator | user
   active: true

The included placeholder Firebase file is only for build convenience; it is NOT a working production backend.

The debug APK is installable on Android. For Play Store release, use a signed release build/keystore.
